/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.service.zigbee.types;

import java.io.IOException;
import java.math.BigInteger;

import org.osgi.service.zigbee.ZigBeeDataInput;
import org.osgi.service.zigbee.ZigBeeDataOutput;
import org.osgi.service.zigbee.ZigBeeDataTypes;
import org.osgi.service.zigbee.descriptions.ZCLSimpleTypeDescription;

/**
 * A singleton class that represents the 'IEEE ADDRESS' data type, as it is
 * defined in the ZigBee Cluster Library specification.
 * 
 * @author $Id: 115495fe6487b52d9b5802796056294b1bd2386b $
 * 
 */
public class ZigBeeIEEE_ADDRESS
		implements ZCLSimpleTypeDescription {

	private final static ZigBeeIEEE_ADDRESS instance = new ZigBeeIEEE_ADDRESS();

	private ZigBeeIEEE_ADDRESS() {
	}

	/**
	 * Gets a singleton instance of this class.
	 * 
	 * @return the singleton instance.
	 */
	public static ZigBeeIEEE_ADDRESS getInstance() {
		return instance;
	}

	@Override
	public String getName() {
		return "IEEE_ADDRESS";
	}

	@Override
	public boolean isAnalog() {
		return false;
	}

	@Override
	public Class< ? > getJavaDataType() {
		return BigInteger.class;
	}

	@Override
	public short getId() {
		return ZigBeeDataTypes.IEEE_ADDRESS;
	}

	@Override
	public void serialize(ZigBeeDataOutput os, Object value) throws IOException {
		ZigBeeDefaultSerializer.serializeDataType(os, ZigBeeDataTypes.IEEE_ADDRESS, value);
	}

	@Override
	public Object deserialize(ZigBeeDataInput is) throws IOException {
		return ZigBeeDefaultSerializer.deserializeDataType(is, ZigBeeDataTypes.IEEE_ADDRESS);
	}

}
