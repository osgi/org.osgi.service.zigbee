/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.test.cases.zigbee.descriptions;

import org.osgi.service.zigbee.descriptions.ZCLAttributeDescription;
import org.osgi.service.zigbee.descriptions.ZCLClusterDescription;
import org.osgi.service.zigbee.descriptions.ZCLCommandDescription;
import org.osgi.service.zigbee.descriptions.ZCLGlobalClusterDescription;

/**
 * @author $Id: 3619daeb1538e830e6e62e9e358f64fc679d35d2 $
 */
public class ZCLClusterDescriptionImpl implements ZCLClusterDescription {

	private ZCLGlobalClusterDescription		global;
	@SuppressWarnings("unused")
	private boolean							isServer;
	private ZCLAttributeDescriptionImpl[]	attributeDescriptions;
	private ZCLCommandDescription[]			commandDescriptions;

	public ZCLClusterDescriptionImpl(ZCLAttributeDescriptionImpl[] attributeDescriptions, ZCLCommandDescription[] commandDescriptions, ZCLGlobalClusterDescription global, boolean isServer) {
		this.global = global;
		this.isServer = isServer;
		this.attributeDescriptions = attributeDescriptions;
		this.commandDescriptions = commandDescriptions;
	}

	public int getId() {
		return global.getClusterId();
	}

	public ZCLGlobalClusterDescription getGlobalClusterDescription() {
		return global;
	}

	public ZCLCommandDescription[] getReceivedCommandDescriptions() {
		return commandDescriptions;
	}

	public ZCLCommandDescription[] getGeneratedCommandDescriptions() {
		throw new UnsupportedOperationException();
	}

	public ZCLAttributeDescription[] getAttributeDescriptions() {
		return attributeDescriptions;
	}

	public String toString() {
		return "" + this.getClass().getName() + "[id: " + global.getClusterId() + ", global: " + global + "]";
	}
}
