/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.impl.service.zigbee.event;

import org.osgi.service.zigbee.ZCLEventListener;
import org.osgi.service.zigbee.ZCLException;
import org.osgi.service.zigbee.ZigBeeEvent;

/**
 * Mocked impl.
 * 
 * @author $Id: bcc28c04448db2bc15752b9c76411581641db474 $
 */
public class ZCLEventListenerImpl implements ZCLEventListener {

	@Override
	public void notifyEvent(ZigBeeEvent event) {
		// TODO
	}

	@Override
	public void onFailure(ZCLException e) {
		// TODO
	}

	@Override
	public void notifyTimeOut(int timeout) {
		// TODO
	}

}
